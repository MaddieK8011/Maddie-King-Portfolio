// startmusic sound made by wav2c

extern const unsigned int startmusic_sampleRate;
extern const unsigned int startmusic_length;
extern const signed char startmusic_data[];
