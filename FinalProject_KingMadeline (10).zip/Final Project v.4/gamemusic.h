// gamemusic sound made by wav2c

extern const unsigned int gamemusic_sampleRate;
extern const unsigned int gamemusic_length;
extern const signed char gamemusic_data[];
