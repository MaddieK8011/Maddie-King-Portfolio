// bulletfire sound made by wav2c

extern const unsigned int bulletfire_sampleRate;
extern const unsigned int bulletfire_length;
extern const signed char bulletfire_data[];
