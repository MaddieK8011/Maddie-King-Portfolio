//methods
void drawTitleScreen();
void drawInstructScreen();
void drawPauseScreen();
void drawLevel1();