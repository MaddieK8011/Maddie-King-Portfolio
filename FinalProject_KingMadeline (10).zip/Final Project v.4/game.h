//game methods
void initGame();
void updateGame();
void drawGame();

int islost;
int vOff1;
int hOff1;
int vOff2;
int hOff2;
