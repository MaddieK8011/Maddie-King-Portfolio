// losemusic sound made by wav2c

extern const unsigned int losemusic_sampleRate;
extern const unsigned int losemusic_length;
extern const signed char losemusic_data[];
