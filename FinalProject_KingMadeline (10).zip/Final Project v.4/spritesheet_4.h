
//{{BLOCK(spritesheet_4)

//======================================================================
//
//	spritesheet_4, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2022-04-28, 16:52:12
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITESHEET_4_H
#define GRIT_SPRITESHEET_4_H

#define spritesheet_4TilesLen 32768
extern const unsigned short spritesheet_4Tiles[16384];

#define spritesheet_4PalLen 512
extern const unsigned short spritesheet_4Pal[256];

#endif // GRIT_SPRITESHEET_4_H

//}}BLOCK(spritesheet_4)
