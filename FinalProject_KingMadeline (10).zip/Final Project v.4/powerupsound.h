// powerupsound sound made by wav2c

extern const unsigned int powerupsound_sampleRate;
extern const unsigned int powerupsound_length;
extern const signed char powerupsound_data[];
