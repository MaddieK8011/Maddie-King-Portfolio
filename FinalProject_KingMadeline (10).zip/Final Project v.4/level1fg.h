
//{{BLOCK(level1fg)

//======================================================================
//
//	level1fg, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 91 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 32 + 2912 + 2048 = 4992
//
//	Time-stamp: 2022-04-28, 17:11:52
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1FG_H
#define GRIT_LEVEL1FG_H

#define level1fgTilesLen 2912
extern const unsigned short level1fgTiles[1456];

#define level1fgMapLen 2048
extern const unsigned short level1fgMap[1024];

#define level1fgPalLen 32
extern const unsigned short level1fgPal[16];

#endif // GRIT_LEVEL1FG_H

//}}BLOCK(level1fg)
